from COO import COO_int
c=COO_int()
c.GenER(2,1,True,1)
c.PrintInfo()
